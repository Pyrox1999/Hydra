Please use this hacking-ttol only with permission!

This app works like Hydra on Kali-Linux. You can change the passlist, if you want. This program picks up randomly a word from the passlist and make a request with the target-site.

Music by SubspaceAudio